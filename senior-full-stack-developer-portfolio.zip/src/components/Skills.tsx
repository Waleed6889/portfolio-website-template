/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { Cpu, Layout, Server, Database, Cloud, Terminal, Sparkles } from "lucide-react";
import { Skill } from "../types";

const SKILL_DATA: Skill[] = [
  // Frontend
  { name: "React 19 / Next.js", level: 96, category: "Frontend", icon: "Layout" },
  { name: "TypeScript", level: 94, category: "Frontend", icon: "Terminal" },
  { name: "Tailwind CSS v4", level: 98, category: "Frontend", icon: "Layout" },
  { name: "Framer Motion", level: 88, category: "Frontend", icon: "Sparkles" },

  // Backend
  { name: "Node.js (NestJS/Express)", level: 92, category: "Backend", icon: "Server" },
  { name: "Python (FastAPI)", level: 85, category: "Backend", icon: "Terminal" },
  { name: "PostgreSQL", level: 88, category: "Backend", icon: "Database" },
  { name: "GraphQL", level: 82, category: "Backend", icon: "Server" },

  // AI & ML
  { name: "Gemini SDK Integration", level: 95, category: "AI & ML", icon: "Cpu" },
  { name: "LangChain Orchestrations", level: 88, category: "AI & ML", icon: "Sparkles" },
  { name: "pgvector & Vector DBs", level: 84, category: "AI & ML", icon: "Database" },
  { name: "Model Tuning & Prompt Ops", level: 90, category: "AI & ML", icon: "Cpu" },

  // Tools & Cloud
  { name: "Docker", level: 86, category: "Tools & Cloud", icon: "Cloud" },
  { name: "AWS Services", level: 82, category: "Tools & Cloud", icon: "Cloud" },
  { name: "CI/CD & Git Actions", level: 90, category: "Tools & Cloud", icon: "Terminal" },
  { name: "Cloudflare (Workers/Edge)", level: 85, category: "Tools & Cloud", icon: "Cloud" }
];

const CATEGORIES = ["All", "Frontend", "Backend", "AI & ML", "Tools & Cloud"] as const;

interface SkillBarProps {
  skill: Skill;
  isVisible: boolean;
}

function SkillBar({ skill, isVisible }: SkillBarProps) {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setWidth(skill.level);
      }, 150);
      return () => clearTimeout(timer);
    } else {
      setWidth(0);
    }
  }, [isVisible, skill.level]);

  // Map icon strings to Lucide components
  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case "Layout":
        return <Layout size={16} />;
      case "Server":
        return <Server size={16} />;
      case "Database":
        return <Database size={16} />;
      case "Cloud":
        return <Cloud size={16} />;
      case "Terminal":
        return <Terminal size={16} />;
      case "Sparkles":
        return <Sparkles size={16} />;
      default:
        return <Cpu size={16} />;
    }
  };

  return (
    <div className="glass-panel p-5 rounded-xl border border-white/5 bg-gray-950/25 flex flex-col space-y-3">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2.5 text-indigo-300">
          <div className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            {renderIcon(skill.icon)}
          </div>
          <span className="font-display font-semibold text-white text-sm sm:text-base">{skill.name}</span>
        </div>
        <span className="font-mono text-xs sm:text-sm text-gray-400 font-semibold">{skill.level}%</span>
      </div>

      {/* Progress Track */}
      <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden relative border border-white/5">
        {/* Animated Fill */}
        <div
          className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-400 rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%` }}
        />
        {/* Pulsing end point highlight */}
        <div
          className="absolute top-0 bottom-0 w-2 bg-white/40 filter blur-xs transition-all duration-1000 ease-out"
          style={{ left: `calc(${width}% - 4px)` }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState<typeof CATEGORIES[number]>("All");
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const filteredSkills = activeCategory === "All"
    ? SKILL_DATA
    : SKILL_DATA.filter(skill => skill.category === activeCategory);

  return (
    <section id="skills" ref={sectionRef} className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8 bg-gray-950/10">
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <Cpu size={14} /> TECH STACK
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Specialized Capabilities & Technical Stack
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Filter Navigation Category Tabs */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-12">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all duration-200 cursor-pointer border ${
                activeCategory === category
                  ? "bg-indigo-500/10 border-indigo-500/40 text-indigo-300 shadow-md"
                  : "border-white/5 hover:border-white/20 text-gray-400 hover:text-white bg-gray-900/40"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredSkills.map((skill, index) => (
            <SkillBar
              key={`${skill.name}-${index}`}
              skill={skill}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
