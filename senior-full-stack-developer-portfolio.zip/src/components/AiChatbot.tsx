/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect, KeyboardEvent } from "react";
import { MessageSquare, X, Send, Sparkles, User, AlertCircle } from "lucide-react";
import { ChatMessage } from "../types";

interface AiChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const SUGGESTED_PROMPTS = [
  "What is your core tech stack?",
  "Tell me about your featured projects",
  "Are you available for contract hire?",
  "What are your consulting rates?",
];

// High-fidelity custom safe parser for rendering simple markdown markers (*bold*, lists, URLs)
function parseSimpleMarkdown(text: string): string {
  let html = text;

  // Escape HTML tags to prevent XSS
  html = html
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // Bold (**text**) -> <strong>text</strong>
  html = html.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

  // Bullet Lists (lines starting with * or -)
  const lines = html.split("\n");
  let inList = false;
  const parsedLines = lines.map((line) => {
    const trimmed = line.trim();
    if (trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
      const content = trimmed.substring(2);
      let listPrefix = "";
      if (!inList) {
        inList = true;
        listPrefix = '<ul class="list-disc pl-5 my-1.5 space-y-1">';
      }
      return `${listPrefix}<li class="text-xs sm:text-sm leading-relaxed">${content}</li>`;
    } else {
      let listSuffix = "";
      if (inList) {
        inList = false;
        listSuffix = "</ul>";
      }
      return listSuffix + line;
    }
  });
  html = parsedLines.join("\n");

  // Numbered Lists (1. text) -> <ol><li>
  // To keep it simple, we just handle standard lists and paragraphs
  html = html.split("\n\n").map(para => {
    if (!para.trim()) return "";
    if (para.startsWith("<ul") || para.startsWith("<li")) return para;
    return `<p class="text-xs sm:text-sm leading-relaxed mb-2">${para.replace(/\n/g, "<br/>")}</p>`;
  }).join("");

  return html;
}

export default function AiChatbot({ isOpen, onClose }: AiChatbotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "bot",
      text: "Welcome! I'm Waleed's Virtual AI Twin. I can share details about his skills, project architectures, remote availability, and contract estimations. What can I help you build today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom when messages update
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);
    setIsError(false);

    try {
      // Map existing conversation messages to structured AI content history
      const history = messages.map((m) => ({
        role: m.sender === "user" ? "user" : "model",
        text: m.text,
      }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: textToSend,
          history,
        }),
      });

      const data = await response.json();

      if (response.ok && data.text) {
        const botMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          sender: "bot",
          text: data.text,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (error) {
      console.error("AI chatbot transmission error:", error);
      setIsError(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage(inputValue);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 w-[90vw] sm:w-[420px] h-[550px] rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col glass-panel bg-gray-950/95 animate-fade-in transition-all">
      {/* Chat Header */}
      <div className="p-4 border-b border-white/5 flex justify-between items-center bg-gradient-to-r from-indigo-500/10 to-purple-500/10">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
            <Sparkles size={16} className="animate-spin" style={{ animationDuration: "5s" }} />
          </div>
          <div>
            <h3 className="text-white text-sm sm:text-base font-display font-bold">Waleed's AI Twin</h3>
            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Online & Primed
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
          aria-label="Close Assistant"
        >
          <X size={18} />
        </button>
      </div>

      {/* Messages Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 max-w-[85%] ${
              msg.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
            }`}
          >
            {/* Avatar badge */}
            <div className={`p-1.5 rounded-lg text-xs font-bold flex-shrink-0 flex items-center justify-center select-none shadow-sm ${
              msg.sender === "user" 
                ? "bg-indigo-600/25 text-indigo-200 border border-indigo-500/20" 
                : "bg-purple-600/20 text-purple-300 border border-purple-500/25"
            }`}>
              {msg.sender === "user" ? <User size={12} /> : "AI"}
            </div>

            {/* Bubble Text */}
            <div
              className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed border font-sans ${
                msg.sender === "user"
                  ? "bg-indigo-500/10 text-white border-indigo-500/20 rounded-tr-none"
                  : "bg-gray-900/45 text-gray-200 border-white/5 rounded-tl-none markdown-body"
              }`}
              dangerouslySetInnerHTML={{ __html: parseSimpleMarkdown(msg.text) }}
            />
          </div>
        ))}

        {/* Loading Bubble state */}
        {isLoading && (
          <div className="flex items-start gap-2.5 max-w-[85%] mr-auto">
            <div className="p-1.5 rounded-lg text-xs font-bold flex-shrink-0 flex items-center justify-center bg-purple-600/20 text-purple-300 border border-purple-500/25">
              AI
            </div>
            <div className="p-3.5 rounded-2xl border border-white/5 bg-gray-900/45 rounded-tl-none flex items-center space-x-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" />
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: "0.2s" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: "0.4s" }} />
            </div>
          </div>
        )}

        {/* Error state */}
        {isError && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-medium">
            <AlertCircle size={14} />
            <span>Network timeout. Retrying request...</span>
            <button 
              onClick={() => handleSendMessage(messages[messages.length - 1].text)}
              className="underline font-bold text-red-300 ml-auto cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Suggested Quick Prompt list */}
      {messages.length === 1 && (
        <div className="px-4 py-2 flex flex-wrap gap-1.5 border-t border-white/5 bg-gray-950/40">
          {SUGGESTED_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="text-[10px] px-2.5 py-1.5 rounded-lg border border-white/5 hover:border-indigo-500/30 text-gray-400 hover:text-indigo-200 hover:bg-indigo-500/5 transition-all text-left cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Chat Input controls */}
      <div className="p-4 border-t border-white/5 bg-gray-950/60 flex items-center space-x-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Ask Waleed's Twin about his rates, projects..."
          className="flex-1 px-4 py-2.5 rounded-xl bg-gray-900 border border-white/5 focus:border-indigo-500 text-white text-xs sm:text-sm placeholder-gray-500 focus:outline-none transition-colors"
          disabled={isLoading}
        />
        <button
          onClick={() => handleSendMessage(inputValue)}
          disabled={!inputValue.trim() || isLoading}
          className="p-2.5 bg-gradient-to-r from-indigo-500 to-indigo-600 disabled:from-indigo-500/20 disabled:to-indigo-600/20 hover:from-indigo-600 hover:to-indigo-700 text-white rounded-xl shadow-md transition-all cursor-pointer disabled:pointer-events-none"
          aria-label="Send message"
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  );
}
