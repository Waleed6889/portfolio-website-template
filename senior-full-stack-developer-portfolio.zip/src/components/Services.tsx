/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Code, Smartphone, LayoutDashboard, Paintbrush, ShieldCheck, ArrowRight } from "lucide-react";

const SERVICES_DATA = [
  {
    id: "frontend",
    title: "Frontend Architecture",
    description: "Designing state-of-the-art modular systems, state managers, and component layouts using React 19, TypeScript, and Tailwind CSS v4. Focus on performance, tree-shaking, and Lighthouse optimization.",
    icon: Code,
    price: "Hourly or Retainer basis",
    features: ["Atomic Component Structure", "Secure state flows (Redux/Zustand)", "Webpack/Vite optimizations", "Bundle size audits"]
  },
  {
    id: "responsive",
    title: "Responsive Deployments",
    description: "Creating highly robust, responsive web frameworks that align with desktop, laptop, mobile, and ultra-wide displays perfectly. Absolutely fluid layout sizing without layout shifts.",
    icon: Smartphone,
    price: "Custom per scope",
    features: ["Desktop-first precision code", "Fluid flex & grid structures", "Touch-target enhancements", "Multi-browser support checks"]
  },
  {
    id: "landing",
    title: "Premium Landing Pages",
    description: "High-conversion marketing landing pages designed with smooth scroll timelines, glassmorphic layouts, floating elements, and on-page SEO integrations to maximize organic conversions.",
    icon: LayoutDashboard,
    price: "Project-based estimates",
    features: ["On-page technical SEO structured data", "AdSense-ready structure layout", "Fast page loads (95+ Lighthouse)", "Integrated Lead trackers"]
  },
  {
    id: "uiux",
    title: "AI Integration & UI Design",
    description: "Embedding conversational LLM engines (like Gemini or Claude) securely behind backend server proxies. Designing chat widgets, voice agents, and high-fidelity mockups.",
    icon: Paintbrush,
    price: "Integration consultancy contracts",
    features: ["Server-side API key encryption", "Custom client-side chatbot styling", "Streaming SSE or WebSocket flows", "Responsive conversational UI design"]
  }
];

export default function Services() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section id="services" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8">
      {/* Background radial glowing effect */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-purple-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <LayoutDashboard size={14} /> MY SERVICES
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Consulting, Design, & Full-Stack Implementation
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES_DATA.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="glass-panel glass-panel-hover p-8 rounded-2xl flex flex-col justify-between h-full group"
              >
                <div>
                  {/* Icon Badge */}
                  <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl w-fit border border-indigo-500/20 group-hover:bg-indigo-500/20 group-hover:scale-110 transition-all duration-300">
                    <Icon size={24} />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-display font-bold text-white mt-6 group-hover:text-indigo-300 transition-colors">
                    {service.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-400 text-xs sm:text-sm mt-3 leading-relaxed font-sans">
                    {service.description}
                  </p>

                  {/* Bullet features */}
                  <div className="mt-6 space-y-2">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-2 text-gray-500 group-hover:text-gray-400 transition-colors text-xs font-sans">
                        <ShieldCheck size={14} className="text-emerald-500/80 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer and CTA links */}
                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-indigo-400">
                    {service.price}
                  </span>
                  <button
                    onClick={scrollToContact}
                    className="flex items-center space-x-1.5 text-xs text-gray-400 hover:text-white font-semibold transition-colors duration-200 cursor-pointer"
                  >
                    <span>Request Estimate</span>
                    <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
