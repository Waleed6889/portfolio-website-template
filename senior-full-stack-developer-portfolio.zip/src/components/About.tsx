/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { User, Award, CheckCircle2, Coffee } from "lucide-react";

interface CounterProps {
  end: number;
  duration?: number;
  suffix?: string;
}

// Simple counter implementation that animates from 0 to 'end'
function Counter({ end, duration = 2000, suffix = "" }: CounterProps) {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          let startTimestamp: number | null = null;
          const step = (timestamp: number) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            setCount(Math.floor(progress * end));
            if (progress < 1) {
              window.requestAnimationFrame(step);
            }
          };
          window.requestAnimationFrame(step);
        }
      },
      { threshold: 0.1 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, [end, duration]);

  return (
    <div ref={elementRef} className="text-3xl sm:text-4xl font-display font-extrabold text-white">
      {count}
      {suffix}
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8">
      {/* Background decoration orbs */}
      <div className="absolute top-1/2 left-0 w-64 h-64 rounded-full bg-indigo-500/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <User size={14} /> ABOUT ME
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            My Passion, Core Philosophy, and Architectural Principles
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            <h3 className="text-xl sm:text-2xl font-display font-bold text-white leading-tight">
              Engineering solutions at the intersection of web performance and cognitive computing.
            </h3>
            <p className="text-gray-400 font-sans leading-relaxed text-sm sm:text-base">
              Over the last 8+ years, I have helped startups and tier-one software enterprise teams translate ambitious ideas into premium, production-ready full-stack applications. My design philosophy is deeply rooted in minimalism, visual hierarchy, and absolute performance: if a website takes more than a second to load or fails screen-reader standards, it isn't ready.
            </p>
            <p className="text-gray-400 font-sans leading-relaxed text-sm sm:text-base">
              My recent focus centers around Generative AI orchestrations. I design systems that leverage models like Gemini and Claude, enabling complex automated workflows, conversational twin agents, and semantic lookup capabilities—while always maintaining complete server-side API credential security and robust local fallbacks.
            </p>

            {/* Core Values / Bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="flex items-start space-x-3">
                <div className="p-1 rounded bg-indigo-500/10 text-indigo-400 mt-1">
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <h4 className="text-white text-sm font-semibold">Performance-First Approach</h4>
                  <p className="text-gray-500 text-xs mt-0.5">Optimizing load times, tree-shaking assets, and maximizing Lighthouse scores.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-1 rounded bg-indigo-500/10 text-indigo-400 mt-1">
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <h4 className="text-white text-sm font-semibold">Accessibility & Compliance</h4>
                  <p className="text-gray-500 text-xs mt-0.5">Delivering fully keyboard-navigable, screen-reader ready, and WCAG-compliant markup.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-1 rounded bg-indigo-500/10 text-indigo-400 mt-1">
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <h4 className="text-white text-sm font-semibold">Secure Server Architectures</h4>
                  <p className="text-gray-500 text-xs mt-0.5">Proxying sensitive operations client-safely and keeping raw API keys fully private.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-1 rounded bg-indigo-500/10 text-indigo-400 mt-1">
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <h4 className="text-white text-sm font-semibold">Modular Design Systems</h4>
                  <p className="text-gray-500 text-xs mt-0.5">Creating atomic, reusable components that adapt flawlessly across mobile, tablet, and 4K views.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Stats Column */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            {/* Stat Card 1 */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-2 border border-white/5 bg-gray-950/20 text-center items-center">
              <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl mb-2">
                <Award size={24} />
              </div>
              <Counter end={8} suffix="+" />
              <span className="text-xs text-gray-400 font-mono uppercase tracking-widest mt-1">
                Years Experience
              </span>
            </div>

            {/* Stat Card 2 */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-2 border border-white/5 bg-gray-950/20 text-center items-center">
              <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl mb-2">
                <CheckCircle2 size={24} />
              </div>
              <Counter end={50} suffix="+" />
              <span className="text-xs text-gray-400 font-mono uppercase tracking-widest mt-1">
                Projects Completed
              </span>
            </div>

            {/* Stat Card 3 */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-2 border border-white/5 bg-gray-950/20 text-center items-center">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl mb-2">
                <User size={24} />
              </div>
              <Counter end={30} suffix="+" />
              <span className="text-xs text-gray-400 font-mono uppercase tracking-widest mt-1">
                Happy Clients
              </span>
            </div>

            {/* Stat Card 4 */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-2 border border-white/5 bg-gray-950/20 text-center items-center">
              <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl mb-2">
                <Coffee size={24} />
              </div>
              <Counter end={1200} suffix="+" />
              <span className="text-xs text-gray-400 font-mono uppercase tracking-widest mt-1">
                Cups of Coffee
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
