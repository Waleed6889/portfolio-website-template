/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { ArrowRight, Github, Linkedin, Twitter, Sparkles, CodeXml } from "lucide-react";

interface HeroProps {
  onOpenChat: () => void;
}

const TYPING_STRINGS = [
  "Senior Full-Stack Engineer",
  "Generative AI Integration Specialist",
  "SaaS Product Architect",
  "Clean Code Advocate"
];

export default function Hero({ onOpenChat }: HeroProps) {
  const [text, setText] = useState("");
  const [loopNum, setLoopNum] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(100);

  // Animated typing effect loop
  useEffect(() => {
    const handleType = () => {
      const currentFullText = TYPING_STRINGS[loopNum % TYPING_STRINGS.length];
      
      if (isDeleting) {
        setText(currentFullText.substring(0, text.length - 1));
        setTypingSpeed(40); // delete faster
      } else {
        setText(currentFullText.substring(0, text.length + 1));
        setTypingSpeed(90); // default typing rate
      }

      if (!isDeleting && text === currentFullText) {
        // Pause at the end of word
        setTypingSpeed(1500);
        setIsDeleting(true);
      } else if (isDeleting && text === "") {
        setIsDeleting(false);
        setLoopNum(loopNum + 1);
        setTypingSpeed(500); // pause before starting next word
      }
    };

    const timer = setTimeout(handleType, typingSpeed);
    return () => clearTimeout(timer);
  }, [text, isDeleting, loopNum, typingSpeed]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 overflow-hidden px-4 sm:px-6 lg:px-8"
    >
      {/* Background Neon Orbs */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 rounded-full bg-indigo-600/15 blur-[120px] animate-glow-1 pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-purple-600/15 blur-[120px] animate-glow-2 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-indigo-500/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

      {/* Grid Overlay for Tech Vibe */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f2937_1px,transparent_1px),linear-gradient(to_bottom,#1f2937_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-20 pointer-events-none" />

      {/* Floating social bar */}
      <div className="hidden lg:flex flex-col space-y-4 absolute left-8 top-1/2 -translate-y-1/2 z-10">
        <a
          href="https://github.com/waleed-dev"
          target="_blank"
          referrerPolicy="no-referrer"
          rel="noopener noreferrer"
          className="p-3 bg-gray-900/40 hover:bg-indigo-500/20 text-gray-400 hover:text-white border border-white/5 hover:border-indigo-500/30 rounded-full transition-all duration-300 shadow-md cursor-pointer hover:scale-110"
          title="GitHub Profile"
        >
          <Github size={18} />
        </a>
        <a
          href="https://linkedin.com/in/waleed-dev"
          target="_blank"
          referrerPolicy="no-referrer"
          rel="noopener noreferrer"
          className="p-3 bg-gray-900/40 hover:bg-indigo-500/20 text-gray-400 hover:text-white border border-white/5 hover:border-indigo-500/30 rounded-full transition-all duration-300 shadow-md cursor-pointer hover:scale-110"
          title="LinkedIn Profile"
        >
          <Linkedin size={18} />
        </a>
        <a
          href="https://twitter.com/waleed_dev"
          target="_blank"
          referrerPolicy="no-referrer"
          rel="noopener noreferrer"
          className="p-3 bg-gray-900/40 hover:bg-indigo-500/20 text-gray-400 hover:text-white border border-white/5 hover:border-indigo-500/30 rounded-full transition-all duration-300 shadow-md cursor-pointer hover:scale-110"
          title="Twitter / X Profile"
        >
          <Twitter size={18} />
        </a>
      </div>

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10 py-12">
        {/* Text Content */}
        <div className="lg:col-span-7 flex flex-col space-y-6 text-center lg:text-left">
          {/* Tagline Badge */}
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full glass-panel border border-white/10 bg-white/5 text-indigo-300 text-xs font-semibold uppercase tracking-wider self-center lg:self-start w-fit shadow-md animate-bounce">
            <Sparkles size={12} className="text-yellow-400 animate-spin" style={{ animationDuration: '3s' }} />
            <span>Open for Remote Contracts</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-display font-extrabold tracking-tight text-white leading-tight">
            Hi, I'm{" "}
            <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-500 bg-clip-text text-transparent">
              Waleed
            </span>
          </h1>

          {/* Typewriter text container with fixed height to prevent content shifting */}
          <div className="h-10 text-lg sm:text-2xl font-mono text-gray-300 flex items-center justify-center lg:justify-start">
            <span>{text}</span>
            <span className="typed-cursor text-indigo-400">|</span>
          </div>

          <p className="text-base sm:text-lg text-gray-400 max-w-xl mx-auto lg:mx-0 font-sans leading-relaxed">
            I build beautiful, highly resilient, full-stack web architectures and integration-ready AI systems. Let my virtual twin show you what we can achieve.
          </p>

          {/* CTA Group */}
          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
            <button
              onClick={() => scrollToSection("projects")}
              className="flex items-center justify-center space-x-2 w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white rounded-xl text-sm font-semibold tracking-wide shadow-lg shadow-indigo-500/20 border border-indigo-400/20 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Explore My Work</span>
              <ArrowRight size={16} />
            </button>

            <button
              onClick={onOpenChat}
              className="flex items-center justify-center space-x-2 w-full sm:w-auto px-6 py-3.5 bg-gray-900/60 hover:bg-gray-800/80 text-white rounded-xl text-sm font-semibold tracking-wide shadow-md border border-white/10 hover:border-indigo-500/30 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <CodeXml size={16} className="text-indigo-400" />
              <span>Consult My AI Twin</span>
            </button>
          </div>
        </div>

        {/* Abstract Graphic / Silicon Valley Style Visual */}
        <div className="lg:col-span-5 flex items-center justify-center">
          <div className="relative w-72 h-72 sm:w-96 sm:h-96 flex items-center justify-center">
            {/* Pulsing visual halo backgrounds */}
            <div className="absolute inset-0 rounded-full border border-indigo-500/10 animate-pulse" />
            <div className="absolute -inset-4 rounded-full border border-purple-500/5 animate-ping opacity-30" style={{ animationDuration: '4s' }} />

            {/* Glowing Graphic Container */}
            <div className="absolute w-60 h-60 sm:w-80 sm:h-80 glass-panel border border-white/10 rounded-2xl shadow-2xl flex items-center justify-center bg-gray-900/30 overflow-hidden group">
              {/* Spinning background lines */}
              <svg
                viewBox="0 0 100 100"
                className="absolute inset-0 w-full h-full opacity-20 group-hover:opacity-30 transition-opacity duration-500"
              >
                <circle cx="50" cy="50" r="45" fill="none" stroke="url(#indigoGrad)" strokeWidth="0.5" strokeDasharray="5, 5" className="animate-spin" style={{ animationDuration: '60s' }} />
                <circle cx="50" cy="50" r="35" fill="none" stroke="url(#purpleGrad)" strokeWidth="0.5" strokeDasharray="10, 5" className="animate-spin" style={{ animationDuration: '40s', animationDirection: 'reverse' }} />
                <defs>
                  <linearGradient id="indigoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#4f46e5" />
                    <stop offset="100%" stopColor="#06b6d4" />
                  </linearGradient>
                  <linearGradient id="purpleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#d946ef" />
                    <stop offset="100%" stopColor="#4f46e5" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Central Abstract Terminal Code Element */}
              <div className="text-left font-mono text-[10px] sm:text-xs text-indigo-300 w-full p-6 leading-relaxed select-none">
                <div className="flex items-center space-x-1.5 pb-3 border-b border-white/5 mb-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                  <span className="text-[9px] text-gray-500 font-sans tracking-wide pl-2">waleed-ai-runtime.log</span>
                </div>
                <div className="text-emerald-400">➜ dev-pipeline init</div>
                <div className="text-gray-500">Initializing fullstack services...</div>
                <div className="text-indigo-400">✔ Loading React 19 Engine</div>
                <div className="text-purple-400">✔ Syncing Gemini-3.5-Flash Core</div>
                <div className="text-cyan-400">✔ Establishing Edge Cache Routes</div>
                <div className="text-white mt-2">const developer = &#123;</div>
                <div className="pl-4 text-pink-400">name: <span className="text-indigo-200">"Waleed"</span>,</div>
                <div className="pl-4 text-pink-400">architecture: <span className="text-indigo-200">"Full-Stack + AI"</span>,</div>
                <div className="pl-4 text-pink-400">philosophy: <span className="text-indigo-200">"Build for Impact"</span></div>
                <div className="text-white">&#125;;</div>
                <div className="text-amber-400 animate-pulse mt-1">➜ STATUS: SECURE & STABLE</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
