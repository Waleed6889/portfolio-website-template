/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, ChangeEvent } from "react";
import { Mail, Linkedin, Github, Instagram, Send, CheckCircle2, AlertTriangle } from "lucide-react";

interface FormState {
  name: string;
  email: string;
  subject: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

export default function Contact() {
  const [formData, setFormData] = useState<FormState>({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle");
  const [statusMessage, setStatusMessage] = useState("");

  const validateEmail = (email: string): boolean => {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(email);
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Clear validation error on change
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const newErrors: FormErrors = {};

    // Basic Validation checks
    if (!formData.name.trim()) {
      newErrors.name = "Your name is required.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Your email address is required.";
    } else if (!validateEmail(formData.email)) {
      newErrors.email = "Please provide a valid email address.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Please write a message.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus("idle");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setSubmitStatus("success");
        setStatusMessage(data.message || "Message submitted successfully!");
        setFormData({ name: "", email: "", subject: "", message: "" });
      } else {
        setSubmitStatus("error");
        setStatusMessage(data.error || "Failed to submit message. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting contact form:", error);
      setSubmitStatus("error");
      setStatusMessage("An unexpected network error occurred. Please check your connection and retry.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8 bg-gray-950/10">
      {/* Background visual halo */}
      <div className="absolute bottom-1/4 left-1/4 w-72 h-72 rounded-full bg-indigo-600/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <Mail size={14} /> CONTACT
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Let's Collaborate on Your Next Venture
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Form and Contact Detail grid split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Details Panel */}
          <div className="lg:col-span-5 flex flex-col space-y-8">
            <div className="glass-panel p-8 rounded-2xl border border-white/5 bg-gray-950/25">
              <h3 className="text-xl font-display font-bold text-white mb-4">Direct Details</h3>
              <p className="text-gray-400 text-xs sm:text-sm font-sans leading-relaxed mb-6">
                Have an ambitious product design scope, enterprise AI automation pipeline, or full-stack architectural migrates to discuss? Shoot me a message directly or connect via my active profiles.
              </p>

              {/* Detail anchor cards */}
              <div className="space-y-4">
                <a
                  href="mailto:waleedrafique15@gmail.com"
                  className="flex items-center space-x-3.5 p-3 rounded-xl border border-white/5 hover:border-indigo-500/20 bg-gray-900/30 hover:bg-gray-900/60 text-gray-300 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg group-hover:bg-indigo-500/20 transition-colors">
                    <Mail size={18} />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Email Direct</span>
                    <p className="text-xs sm:text-sm font-semibold">waleedrafique15@gmail.com</p>
                  </div>
                </a>
              </div>
            </div>

            {/* Social Anchor Panel */}
            <div className="glass-panel p-8 rounded-2xl border border-white/5 bg-gray-950/25">
              <h3 className="text-xl font-display font-bold text-white mb-4">Find Me Across the Web</h3>
              <div className="grid grid-cols-2 gap-4">
                <a
                  href="https://linkedin.com/in/waleed-dev"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2.5 p-3 rounded-xl border border-white/5 hover:border-indigo-500/20 hover:bg-indigo-500/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  <Linkedin size={18} className="text-indigo-400" />
                  <span className="text-xs font-semibold">LinkedIn</span>
                </a>
                <a
                  href="https://github.com/waleed-dev"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2.5 p-3 rounded-xl border border-white/5 hover:border-indigo-500/20 hover:bg-indigo-500/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  <Github size={18} className="text-indigo-400" />
                  <span className="text-xs font-semibold">GitHub</span>
                </a>
                <a
                  href="https://instagram.com/waleed_dev"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2.5 p-3 rounded-xl border border-white/5 hover:border-indigo-500/20 hover:bg-indigo-500/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  <Instagram size={18} className="text-indigo-400" />
                  <span className="text-xs font-semibold">Instagram</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Form Panel */}
          <div className="lg:col-span-7">
            <div className="glass-panel p-8 rounded-2xl border border-white/5 bg-gray-950/25">
              <h3 className="text-xl font-display font-bold text-white mb-6">Send an Inquiry</h3>

              {/* Error/Success Feedbacks */}
              {submitStatus === "success" && (
                <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-start space-x-3 text-xs sm:text-sm">
                  <CheckCircle2 size={18} className="text-emerald-400 flex-shrink-0 mt-0.5 animate-bounce" />
                  <span>{statusMessage}</span>
                </div>
              )}

              {submitStatus === "error" && (
                <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 flex items-start space-x-3 text-xs sm:text-sm">
                  <AlertTriangle size={18} className="text-red-400 flex-shrink-0 mt-0.5" />
                  <span>{statusMessage}</span>
                </div>
              )}

              {/* Form Element */}
              <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Name field */}
                  <div className="flex flex-col space-y-1.5">
                    <label htmlFor="name" className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wide">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. Jane Doe"
                      className={`w-full px-4 py-3 rounded-xl bg-gray-900/60 border ${
                        errors.name ? "border-red-500/50 focus:border-red-500" : "border-white/5 focus:border-indigo-500"
                      } text-white text-xs sm:text-sm placeholder-gray-600 focus:outline-none transition-all`}
                    />
                    {errors.name && <span className="text-red-400 text-[10px] sm:text-xs font-medium">{errors.name}</span>}
                  </div>

                  {/* Email field */}
                  <div className="flex flex-col space-y-1.5">
                    <label htmlFor="email" className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wide">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="e.g. jane@example.com"
                      className={`w-full px-4 py-3 rounded-xl bg-gray-900/60 border ${
                        errors.email ? "border-red-500/50 focus:border-red-500" : "border-white/5 focus:border-indigo-500"
                      } text-white text-xs sm:text-sm placeholder-gray-600 focus:outline-none transition-all`}
                    />
                    {errors.email && <span className="text-red-400 text-[10px] sm:text-xs font-medium">{errors.email}</span>}
                  </div>
                </div>

                {/* Subject field */}
                <div className="flex flex-col space-y-1.5">
                  <label htmlFor="subject" className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wide">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="e.g. SaaS Platform Design Scope"
                    className="w-full px-4 py-3 rounded-xl bg-gray-900/60 border border-white/5 focus:border-indigo-500 text-white text-xs sm:text-sm placeholder-gray-600 focus:outline-none transition-all"
                  />
                </div>

                {/* Message field */}
                <div className="flex flex-col space-y-1.5">
                  <label htmlFor="message" className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wide">
                    Message Body *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Describe your design specifications, budget framework, and core objectives..."
                    className={`w-full px-4 py-3 rounded-xl bg-gray-900/60 border ${
                      errors.message ? "border-red-500/50 focus:border-red-500" : "border-white/5 focus:border-indigo-500"
                    } text-white text-xs sm:text-sm placeholder-gray-600 focus:outline-none transition-all resize-none`}
                  />
                  {errors.message && <span className="text-red-400 text-[10px] sm:text-xs font-medium">{errors.message}</span>}
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center justify-center space-x-2.5 w-full px-6 py-4 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 disabled:from-indigo-500/40 disabled:to-indigo-600/40 text-white rounded-xl text-xs sm:text-sm font-semibold tracking-wide shadow-lg shadow-indigo-500/20 border border-indigo-400/20 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer disabled:pointer-events-none"
                >
                  {isSubmitting ? (
                    <>
                      {/* Spinner loading graphic */}
                      <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Transmitting Inquiry...</span>
                    </>
                  ) : (
                    <>
                      <Send size={14} />
                      <span>Transmit Inquiry</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
