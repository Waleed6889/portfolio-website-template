/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { Menu, X, Terminal, MessageSquare } from "lucide-react";

interface NavbarProps {
  onOpenChat: () => void;
}

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "services", label: "Services" },
  { id: "contact", label: "Contact" },
];

export default function Navbar({ onOpenChat }: NavbarProps) {
  const [activeSection, setActiveSection] = useState("home");
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Monitor scroll height to apply glassmorphism style and track active section
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Simple active section highlights
      const scrollPosition = window.scrollY + 200;
      for (const link of NAV_LINKS) {
        const element = document.getElementById(link.id);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(link.id);
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLinkClick = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of the sticky navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <nav
      id="navbar"
      className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
        isScrolled
          ? "glass-panel py-3 shadow-lg border-b border-white/5"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo / Title */}
          <button
            onClick={() => handleLinkClick("home")}
            className="flex items-center space-x-2 text-white font-display font-bold text-xl tracking-tight cursor-pointer"
          >
            <div className="p-1.5 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-400">
              <Terminal size={18} />
            </div>
            <span className="bg-gradient-to-r from-white via-indigo-200 to-indigo-400 bg-clip-text text-transparent">
              Waleed
            </span>
          </button>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-6">
            <div className="flex items-center space-x-1 glass-panel px-4 py-1.5 rounded-full border border-white/5 bg-gray-950/35">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`px-3.5 py-1 rounded-full text-xs font-medium tracking-wide transition-all duration-200 cursor-pointer ${
                    activeSection === link.id
                      ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                      : "text-gray-400 hover:text-white border border-transparent"
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* AI Assistant Quick Trigger CTA */}
            <button
              onClick={onOpenChat}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-lg text-xs font-semibold tracking-wide shadow-md shadow-indigo-500/20 border border-indigo-400/30 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <MessageSquare size={14} className="animate-pulse" />
              <span>Ask My AI Twin</span>
            </button>
          </div>

          {/* Mobile Navigation Toggle Button */}
          <div className="md:hidden flex items-center space-x-2">
            <button
              onClick={onOpenChat}
              className="p-2 bg-indigo-500/15 border border-indigo-500/20 rounded-lg text-indigo-400 cursor-pointer"
              aria-label="AI Twin Assistant"
            >
              <MessageSquare size={16} />
            </button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-gray-400 hover:text-white focus:outline-none cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <div className="md:hidden glass-panel border-b border-white/5 bg-gray-950/95 absolute top-full left-0 w-full py-4 px-4 space-y-2">
          {NAV_LINKS.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`block w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                activeSection === link.id
                  ? "bg-indigo-500/10 text-indigo-300 border-l-4 border-indigo-500"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              {link.label}
            </button>
          ))}
          <div className="pt-2 border-t border-white/5">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenChat();
              }}
              className="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg text-sm font-semibold tracking-wide shadow-lg shadow-indigo-500/25 border border-indigo-400/25 cursor-pointer"
            >
              <MessageSquare size={16} />
              <span>Consult with my AI Twin</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
