/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react";
import { ArrowUp, Terminal, Github, Linkedin, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleLinkClick = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <footer className="relative bg-gray-950 border-t border-white/5 py-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Scroll to Top floating widget */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 left-6 z-40 p-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-lg border border-indigo-500/30 transition-all duration-300 hover:-translate-y-1 cursor-pointer animate-bounce"
          title="Scroll to Top"
          aria-label="Scroll to top of page"
        >
          <ArrowUp size={16} />
        </button>
      )}

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
        {/* Brand details logo */}
        <button
          onClick={scrollToTop}
          className="flex items-center space-x-2 text-white font-display font-bold text-lg cursor-pointer"
        >
          <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
            <Terminal size={16} />
          </div>
          <span className="bg-gradient-to-r from-white via-indigo-200 to-indigo-400 bg-clip-text text-transparent">
            Waleed
          </span>
        </button>

        {/* Dynamic anchor navigations */}
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-2">
          {["home", "about", "skills", "projects", "services", "contact"].map((section) => (
            <button
              key={section}
              onClick={() => handleLinkClick(section)}
              className="text-xs text-gray-500 hover:text-white transition-colors capitalize font-medium cursor-pointer"
            >
              {section}
            </button>
          ))}
        </div>

        {/* Standard responsive social icons */}
        <div className="flex items-center space-x-4">
          <a
            href="https://github.com/waleed-dev"
            target="_blank"
            referrerPolicy="no-referrer"
            rel="noopener noreferrer"
            className="text-gray-500 hover:text-white transition-colors"
            title="GitHub"
          >
            <Github size={16} />
          </a>
          <a
            href="https://linkedin.com/in/waleed-dev"
            target="_blank"
            referrerPolicy="no-referrer"
            rel="noopener noreferrer"
            className="text-gray-500 hover:text-white transition-colors"
            title="LinkedIn"
          >
            <Linkedin size={16} />
          </a>
          <a
            href="https://twitter.com/waleed_dev"
            target="_blank"
            referrerPolicy="no-referrer"
            rel="noopener noreferrer"
            className="text-gray-500 hover:text-white transition-colors"
            title="Twitter"
          >
            <Twitter size={16} />
          </a>
          <a
            href="https://instagram.com/waleed_dev"
            target="_blank"
            referrerPolicy="no-referrer"
            rel="noopener noreferrer"
            className="text-gray-500 hover:text-white transition-colors"
            title="Instagram"
          >
            <Instagram size={16} />
          </a>
        </div>
      </div>

      {/* Sub-footer copyright lines */}
      <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
        <p className="text-[11px] sm:text-xs text-gray-600 font-mono">
          &copy; {new Date().getFullYear()} Waleed. All Rights Reserved.
        </p>
        <p className="text-[11px] sm:text-xs text-gray-600 font-sans tracking-wide">
          Designed with absolute precision • Performance and WCAG AAA optimized.
        </p>
      </div>
    </footer>
  );
}
