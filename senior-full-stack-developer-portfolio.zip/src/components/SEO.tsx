/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from "react";

export default function SEO() {
  useEffect(() => {
    // 1. Update primary Document Title
    document.title = "Waleed | Senior Full-Stack & AI Systems Architect";

    // 2. Set description meta element
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement("meta");
      metaDescription.setAttribute("name", "description");
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute(
      "content",
      "Official portfolio of Waleed, a Senior Full-Stack Software & AI Engineer. Specializing in high-performance React frontends, secure backend architectures, and Gemini model orchestrations."
    );

    // 3. Set keywords meta element
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement("meta");
      metaKeywords.setAttribute("name", "keywords");
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute(
      "content",
      "Waleed, Senior Full-Stack Developer, AI Software Engineer, React Developer, Tailwind CSS, TypeScript, Gemini API Integration, SaaS Architect, Silicon Valley Freelancer, Web Performance Expert"
    );

    // 4. Set Open Graph Social tags
    const setMetaProperty = (property: string, content: string) => {
      let meta = document.querySelector(`meta[property="${property}"]`);
      if (!meta) {
        meta = document.createElement("meta");
        meta.setAttribute("property", property);
        document.head.appendChild(meta);
      }
      meta.setAttribute("content", content);
    };

    setMetaProperty("og:title", "Waleed | Senior Full-Stack & AI Systems Architect");
    setMetaProperty(
      "og:description",
      "Explore engineering milestones, high-performance web applications, and interactive AI solutions built by Waleed."
    );
    setMetaProperty("og:type", "website");
    setMetaProperty("og:image", "https://example.com/social-preview.jpg");

    // 5. Inject JSON-LD Schema structured data
    const schemaId = "jsonld-seo-schema";
    let scriptSchema = document.getElementById(schemaId);
    if (!scriptSchema) {
      scriptSchema = document.createElement("script");
      scriptSchema.setAttribute("type", "application/ld+json");
      scriptSchema.setAttribute("id", schemaId);
      document.head.appendChild(scriptSchema);
    }

    const jsonLdData = {
      "@context": "https://schema.org",
      "@type": "Person",
      "name": "Waleed",
      "jobTitle": "Senior Full-Stack & AI Solutions Architect",
      "url": window.location.origin,
      "email": "waleedrafique15@gmail.com",
      "sameAs": [
        "https://github.com/waleed-dev",
        "https://linkedin.com/in/waleed-dev",
        "https://twitter.com/waleed_dev"
      ],
      "knowsAbout": [
        "Software Engineering",
        "Full-Stack Web Development",
        "Artificial Intelligence",
        "Generative AI",
        "React",
        "TypeScript",
        "API Design",
        "UI/UX Design"
      ]
    };
    scriptSchema.textContent = JSON.stringify(jsonLdData);

    return () => {
      // Clean up Schema script element on unmount
      const scriptToRemove = document.getElementById(schemaId);
      if (scriptToRemove) {
        scriptToRemove.remove();
      }
    };
  }, []);

  return null; // Side-effect only component
}
