/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Briefcase, ArrowUpRight, Github, Filter, Sparkles, CodeXml } from "lucide-react";
import { Project } from "../types";

const PROJECTS_DATA: Project[] = [
  {
    id: "aetheria",
    title: "Aetheria Enterprise AI",
    description: "An advanced real-time telemetry dashboard monitoring token consumption, request latency, and safety thresholds across LLM deployments.",
    longDescription: "Features interactive high-performance canvas diagrams, customizable alert triggers, automated report compiles, and a secure multi-tenant admin portal.",
    category: "ai",
    techStack: ["React 19", "FastAPI", "Tailwind CSS v4", "D3.js", "Recharts"],
    image: "linear-gradient(135deg, #4f46e5 0%, #06b6d4 100%)",
    liveUrl: "https://example.com/aetheria",
    githubUrl: "https://github.com/waleed-dev/aetheria-ai",
    featured: true
  },
  {
    id: "synthetix",
    title: "Synthetix Code Copilot",
    description: "A secure, local-first VS Code extension providing autocomplete and real-time AST security scanning utilizing optimized models.",
    longDescription: "Bypasses external servers for sensitive code bases by executing fine-tuned models locally. Features semantic searches and automatic test suite creation.",
    category: "ai",
    techStack: ["TypeScript", "Rust", "WebAssembly", "Ollama", "gRPC"],
    image: "linear-gradient(135deg, #7c3aed 0%, #db2777 100%)",
    liveUrl: "https://example.com/synthetix",
    githubUrl: "https://github.com/waleed-dev/synthetix",
    featured: true
  },
  {
    id: "vortex",
    title: "Vortex Headless Commerce",
    description: "An ultra-fast, global edge headless commerce store powered by smart inventory caches and real-time personalized recommendations.",
    longDescription: "Leverages edge functions for geo-cached price structures, instant product queries, WebSocket-driven stock updates, and a single-click checkout flow.",
    category: "fullstack",
    techStack: ["Next.js", "GraphQL", "PostgreSQL", "Redis", "Stripe SDK"],
    image: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)",
    liveUrl: "https://example.com/vortex",
    githubUrl: "https://github.com/waleed-dev/vortex-commerce",
    featured: true
  },
  {
    id: "orbit",
    title: "Orbit Task Management",
    description: "A collaborative Kanban workflow interface styled with gorgeous fluid drag-and-drop mechanics and synchronized multi-user hubs.",
    longDescription: "Includes nested task matrices, instant chat channels, secure profile logins, and an inline Gantt chart tracker styled with custom layouts.",
    category: "frontend",
    techStack: ["React", "TypeScript", "Tailwind CSS", "Framer Motion", "WebSockets"],
    image: "linear-gradient(135deg, #059669 0%, #0d9488 100%)",
    liveUrl: "https://example.com/orbit",
    githubUrl: "https://github.com/waleed-dev/orbit-tasks",
    featured: false
  },
  {
    id: "neuroscribe",
    title: "NeuralScribe Content Suite",
    description: "An AI-powered writer and technical SEO audit companion that drafts rich essays and formats custom templates.",
    longDescription: "Connects securely to backend AI models to analyze keywords, write standard drafts, audit reading indexes, and publish to popular headless CMS tools.",
    category: "ai",
    techStack: ["React", "Node.js", "Express", "Gemini API", "Tailwind v4"],
    image: "linear-gradient(135deg, #ea580c 0%, #d97706 100%)",
    liveUrl: "https://example.com/neuroscribe",
    githubUrl: "https://github.com/waleed-dev/neuroscribe",
    featured: false
  },
  {
    id: "helix",
    title: "Helix Fitness Tracking Suite",
    description: "A premium mobile companion monitoring workout statistics, heart distributions, and meal counts with offline-first synchronization.",
    longDescription: "Syncs instantly back online. Generates weekly summaries, calorie counts, and customized goals using advanced charts.",
    category: "mobile",
    techStack: ["React Native", "TypeScript", "Redux Toolkit", "SQLite", "D3.js"],
    image: "linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)",
    liveUrl: "https://example.com/helix",
    githubUrl: "https://github.com/waleed-dev/helix-fit",
    featured: false
  }
];

const FILTER_CATEGORIES = [
  { id: "all", label: "All Projects" },
  { id: "ai", label: "AI & ML" },
  { id: "fullstack", label: "Full-Stack" },
  { id: "frontend", label: "Frontend" },
  { id: "mobile", label: "Mobile" },
];

export default function Projects() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  const filteredProjects = activeFilter === "all"
    ? PROJECTS_DATA
    : PROJECTS_DATA.filter(project => project.category === activeFilter);

  return (
    <section id="projects" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8 bg-gray-950/20">
      {/* Decorative Blur Backgrounds */}
      <div className="absolute bottom-0 right-0 w-80 h-80 rounded-full bg-indigo-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <Briefcase size={14} /> RECENT WORK
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Featured Projects & Engineering Milestones
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Project Filter Controls */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-12">
          <div className="flex items-center space-x-2 text-gray-500 text-xs font-mono uppercase mr-4 tracking-widest">
            <Filter size={12} />
            <span>Filter:</span>
          </div>
          {FILTER_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveFilter(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all duration-200 cursor-pointer border ${
                activeFilter === cat.id
                  ? "bg-indigo-500/10 border-indigo-500/40 text-indigo-300 shadow-md shadow-indigo-500/5"
                  : "border-white/5 hover:border-white/10 text-gray-400 hover:text-white bg-gray-900/25"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="glass-panel rounded-2xl overflow-hidden border border-white/5 bg-gray-950/15 flex flex-col h-full group transition-all duration-300 hover:border-indigo-500/30 hover:shadow-2xl hover:shadow-indigo-500/5"
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Project Card Mockup Banner */}
              <div
                className="h-48 w-full relative flex items-center justify-center overflow-hidden border-b border-white/5"
                style={{ background: project.image }}
              >
                {/* Visual mesh overlay */}
                <div className="absolute inset-0 bg-gray-950/15 group-hover:bg-gray-950/10 transition-colors duration-300" />
                
                {/* Graphic mockup details */}
                <div className="relative z-10 w-[80%] h-[75%] glass-panel rounded-xl border border-white/10 flex flex-col p-4 shadow-xl translate-y-2 group-hover:translate-y-0 transition-all duration-500 bg-gray-950/40">
                  <div className="flex items-center space-x-1 border-b border-white/5 pb-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-indigo-500" />
                    <span className="w-2 h-2 rounded-full bg-purple-500" />
                    <span className="w-2 h-2 rounded-full bg-pink-500" />
                    <span className="text-[8px] text-gray-400 font-mono tracking-wider ml-2">{project.id}-app.domain</span>
                  </div>
                  {/* Abstract preview content */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div className="h-2 w-12 bg-indigo-500/40 rounded" />
                    <div className="space-y-1">
                      <div className="h-1.5 w-full bg-white/10 rounded" />
                      <div className="h-1.5 w-[85%] bg-white/10 rounded" />
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="h-4 w-10 bg-indigo-500/20 border border-indigo-500/30 rounded flex items-center justify-center">
                        <span className="text-[6px] text-indigo-300 font-mono font-bold uppercase">PROD</span>
                      </div>
                      <div className="h-3 w-3 rounded-full bg-indigo-500/30 flex items-center justify-center">
                        <Sparkles size={6} className="text-indigo-300" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick overlay link buttons on hover */}
                <div className={`absolute inset-0 bg-gray-950/80 backdrop-blur-md flex items-center justify-center space-x-4 transition-all duration-300 ${
                  hoveredProject === project.id ? "opacity-100" : "opacity-0 pointer-events-none"
                }`}>
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-md transition-transform duration-200 hover:scale-105 cursor-pointer"
                  >
                    <span>Live Demo</span>
                    <ArrowUpRight size={14} />
                  </a>
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-1.5 px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white border border-white/10 rounded-lg text-xs font-semibold shadow-md transition-transform duration-200 hover:scale-105 cursor-pointer"
                  >
                    <Github size={14} />
                    <span>Source Code</span>
                  </a>
                </div>
              </div>

              {/* Project Card Text Content */}
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  {/* Category tag */}
                  <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-400 font-semibold">
                    {project.category === "ai" ? "Artificial Intelligence" : project.category}
                  </span>
                  
                  {/* Title */}
                  <h3 className="text-lg font-display font-bold text-white mt-1.5 group-hover:text-indigo-300 transition-colors">
                    {project.title}
                  </h3>
                  
                  {/* Short description */}
                  <p className="text-gray-400 text-xs sm:text-sm mt-2 leading-relaxed font-sans">
                    {project.description}
                  </p>
                  
                  {/* Long description shown inside cards smoothly */}
                  {project.longDescription && (
                    <p className="text-gray-500 text-[11px] sm:text-xs mt-3 leading-relaxed border-t border-white/5 pt-3 font-sans">
                      {project.longDescription}
                    </p>
                  )}
                </div>

                {/* Tech Stack Badge List */}
                <div className="mt-6 flex flex-wrap gap-1.5 pt-4 border-t border-white/5">
                  {project.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md bg-gray-900/60 border border-white/5 text-gray-400 text-[10px] font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
