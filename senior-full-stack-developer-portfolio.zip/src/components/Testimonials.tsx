/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Quote, Star } from "lucide-react";
import { Testimonial } from "../types";

const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: "test-1",
    name: "Sarah Jenkins",
    role: "VP of Engineering",
    company: "SaaSify Systems Labs",
    content: "Waleed is an absolute full-stack virtuoso. He helped us migrate our legacy applications to a modern React architecture, and rebuilt our key interfaces with incredible care. The app speed doubled overnight, and our Lighthouse scores are pristine.",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    rating: 5
  },
  {
    id: "test-2",
    name: "Marcus Thorne",
    role: "Founder & CEO",
    company: "Aetheria Commerce",
    content: "We hired Waleed to design and build our headless commerce store from scratch. His commitment to speed and detail is unmatched. He also implemented a fully secure Gemini chat assistant proxy that handles client inquiries perfectly. Exceptional talent!",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    rating: 5
  },
  {
    id: "test-3",
    name: "Elena Rostova",
    role: "Senior Recruiter",
    company: "Silicon Talent Partners",
    content: "When evaluating engineers for our clients, we look for absolute code cleanliness and execution. Waleed's technical portfolio, fluid design standards, and comprehensive on-page SEO integration made him an instant match. Highly recommended!",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150",
    rating: 5
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8">
      {/* Background decoration blur */}
      <div className="absolute top-1/2 right-0 w-72 h-72 rounded-full bg-purple-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <Quote size={14} /> TESTIMONIALS
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Trusted by Leaders & Industry Professionals
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((item) => (
            <div
              key={item.id}
              className="glass-panel glass-panel-hover p-8 rounded-2xl flex flex-col justify-between h-full border border-white/5 bg-gray-950/25 relative group"
            >
              {/* Quote icon mark */}
              <div className="absolute top-6 right-6 text-indigo-500/10 group-hover:text-indigo-500/20 transition-colors pointer-events-none">
                <Quote size={48} />
              </div>

              <div>
                {/* Rating Stars */}
                <div className="flex items-center space-x-1 mb-5">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} size={14} fill="#f59e0b" className="text-amber-500" />
                  ))}
                </div>

                {/* Feedback Content */}
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-sans italic">
                  "{item.content}"
                </p>
              </div>

              {/* User Bio Footer */}
              <div className="flex items-center space-x-4 mt-8 pt-6 border-t border-white/5">
                {/* Visual Avatar Placeholder with name initials */}
                <div className="w-11 h-11 rounded-full bg-indigo-500/10 border border-indigo-500/25 flex items-center justify-center text-indigo-300 font-display font-bold text-sm select-none shadow">
                  {item.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <h4 className="text-white text-sm sm:text-base font-display font-bold">
                    {item.name}
                  </h4>
                  <p className="text-[11px] text-gray-500 font-mono font-medium mt-0.5">
                    {item.role} • <span className="text-indigo-400">{item.company}</span>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
