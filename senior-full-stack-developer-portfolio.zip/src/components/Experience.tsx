/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Briefcase, GraduationCap, Calendar, Award } from "lucide-react";
import { ExperienceItem } from "../types";

const TIMELINE_DATA: ExperienceItem[] = [
  // Work Experience
  {
    id: "work-1",
    role: "Lead Fullstack & AI Solutions Architect",
    company: "Aetheria Systems Labs",
    period: "2024 - Present",
    description: [
      "Pioneered secure proxy pipelines integrating Gemini Pro models with React frontends, reducing token leaks by 100%.",
      "Led a team of 4 frontend engineers implementing D3 analytics grids, decreasing render lags by 40% on enterprise charts.",
      "Re-architected client build pipelines to Vite + Tailwind, achieving average page load weights 60% below industry standard."
    ],
    type: "work"
  },
  {
    id: "work-2",
    role: "Senior Full-Stack Developer",
    company: "CloudGrid Platforms Inc.",
    period: "2021 - 2024",
    description: [
      "Engineered high-concurrency Node.js endpoints handling up to 50K API requests per minute with Redis caching structures.",
      "Developed a custom drag-and-drop workflow dashboard used by over 100 enterprise clients.",
      "Designed pixel-perfect landing views and optimized Core Web Vitals, elevating Lighthouse performance scores to 98+."
    ],
    type: "work"
  },
  {
    id: "work-3",
    role: "Frontend Developer",
    company: "Vortex Technologies",
    period: "2018 - 2021",
    description: [
      "Crafted mobile-responsive React applications, single-page sites, and checkout systems styled with fluid layout modules.",
      "Decreased DOM structures by 30% and improved input responses through component splitting and hook stabilization.",
      "Conducted on-page SEO optimization audits, leading to a 45% organic increase in weekly search queries."
    ],
    type: "work"
  },
  // Education
  {
    id: "edu-1",
    role: "M.S. in Computer Science (Artificial Intelligence)",
    company: "Stanford University Graduate School",
    period: "2016 - 2018",
    description: [
      "Specialized in Semantic Architectures, Language Orchestrations, and Neural Net Optimization.",
      "Completed Master Thesis: 'Optimizing Token Caches on Edge Nodes for Mobile Client Delivery'."
    ],
    type: "education"
  },
  {
    id: "edu-2",
    role: "B.S. in Software Engineering",
    company: "University of California, Berkeley",
    period: "2012 - 2016",
    description: [
      "Graduated with Summa Cum Laude honors. Active contributor to open-source developer toolkits.",
      "Core courses: Algorithms, Data Systems, Software Design Patterns, Web Systems."
    ],
    type: "education"
  }
];

export default function Experience() {
  const workItems = TIMELINE_DATA.filter(item => item.type === "work");
  const educationItems = TIMELINE_DATA.filter(item => item.type === "education");

  return (
    <section id="experience" className="py-24 relative overflow-hidden px-4 sm:px-6 lg:px-8 bg-gray-950/20">
      {/* Background neon orbs */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 rounded-full bg-indigo-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-xs font-semibold tracking-widest text-indigo-400 uppercase mb-3 font-mono flex items-center justify-center gap-2">
            <Calendar size={14} /> TIMELINE
          </h2>
          <p className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
            Education & Professional Career Milestones
          </p>
          <div className="mt-4 w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
        </div>

        {/* Timeline Grid Split */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Career Path */}
          <div className="flex flex-col">
            <div className="flex items-center space-x-3 mb-8">
              <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                <Briefcase size={20} />
              </div>
              <h3 className="text-2xl font-display font-bold text-white tracking-tight">Professional Journey</h3>
            </div>

            <div className="space-y-12 border-l-2 border-indigo-500/15 pl-6 sm:pl-8 ml-4 sm:ml-5 relative">
              {workItems.map((item) => (
                <div key={item.id} className="relative group">
                  {/* Timeline Point Bullet Node */}
                  <div className="absolute -left-10 sm:-left-12 top-1.5 w-4 h-4 rounded-full bg-indigo-600 border-4 border-[#0b0f19] group-hover:bg-indigo-400 group-hover:scale-125 transition-all duration-300 shadow shadow-indigo-500/50" />
                  
                  {/* Date Badge */}
                  <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-[10px] font-mono font-bold mb-3 uppercase tracking-wider">
                    <Calendar size={10} />
                    <span>{item.period}</span>
                  </div>

                  {/* Title and Company */}
                  <h4 className="text-lg font-display font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {item.role}
                  </h4>
                  <span className="text-xs sm:text-sm text-indigo-400 font-semibold font-mono">
                    {item.company}
                  </span>

                  {/* Description points list */}
                  <ul className="mt-4 space-y-2.5">
                    {item.description.map((bullet, idx) => (
                      <li key={idx} className="flex items-start text-xs sm:text-sm text-gray-400 font-sans leading-relaxed">
                        <span className="text-indigo-500 font-bold mr-2 select-none">•</span>
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Education Path */}
          <div className="flex flex-col">
            <div className="flex items-center space-x-3 mb-8">
              <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <GraduationCap size={20} />
              </div>
              <h3 className="text-2xl font-display font-bold text-white tracking-tight">Academic Foundations</h3>
            </div>

            <div className="space-y-12 border-l-2 border-purple-500/15 pl-6 sm:pl-8 ml-4 sm:ml-5 relative">
              {educationItems.map((item) => (
                <div key={item.id} className="relative group">
                  {/* Timeline Point Bullet Node */}
                  <div className="absolute -left-10 sm:-left-12 top-1.5 w-4 h-4 rounded-full bg-purple-600 border-4 border-[#0b0f19] group-hover:bg-purple-400 group-hover:scale-125 transition-all duration-300 shadow shadow-purple-500/50" />
                  
                  {/* Date Badge */}
                  <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[10px] font-mono font-bold mb-3 uppercase tracking-wider">
                    <Calendar size={10} />
                    <span>{item.period}</span>
                  </div>

                  {/* Title and University */}
                  <h4 className="text-lg font-display font-bold text-white group-hover:text-purple-300 transition-colors">
                    {item.role}
                  </h4>
                  <span className="text-xs sm:text-sm text-purple-400 font-semibold font-mono">
                    {item.company}
                  </span>

                  {/* Description points list */}
                  <ul className="mt-4 space-y-2.5">
                    {item.description.map((bullet, idx) => (
                      <li key={idx} className="flex items-start text-xs sm:text-sm text-gray-400 font-sans leading-relaxed">
                        <span className="text-purple-500 font-bold mr-2 select-none">•</span>
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
