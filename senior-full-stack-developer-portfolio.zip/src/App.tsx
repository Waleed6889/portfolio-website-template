/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import SEO from "./components/SEO";
import ScrollProgressBar from "./components/ScrollProgressBar";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Services from "./components/Services";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import AiChatbot from "./components/AiChatbot";
import { Sparkles } from "lucide-react";

export default function App() {
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Smooth screen entry loading screen simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0b0f19] text-white">
        {/* Animated glowing loader */}
        <div className="relative flex items-center justify-center w-20 h-20">
          <div className="absolute inset-0 rounded-full border border-indigo-500/10 animate-pulse" />
          <div className="absolute -inset-4 rounded-full border-2 border-purple-500/15 animate-spin" style={{ animationDuration: "3s" }} />
          <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 border border-indigo-500/25">
            <Sparkles size={24} className="animate-bounce" />
          </div>
        </div>
        <h1 className="mt-6 font-display font-bold text-lg tracking-wider bg-gradient-to-r from-white via-indigo-200 to-indigo-400 bg-clip-text text-transparent">
          WALEED
        </h1>
        <p className="mt-2 text-xs font-mono text-gray-500 uppercase tracking-widest animate-pulse">
          Virtual Space Syncing...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0f19] text-gray-100 flex flex-col relative">
      {/* On-Page technical SEO injector */}
      <SEO />

      {/* Reading scroll progress indicator */}
      <ScrollProgressBar />

      {/* Primary Sticky Header */}
      <Navbar onOpenChat={() => setIsAiChatOpen(true)} />

      {/* Main Section Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero onOpenChat={() => setIsAiChatOpen(true)} />

        {/* About Info Section */}
        <About />

        {/* Interactive Skills Progress Bars */}
        <Skills />

        {/* Projects Grid + Filter tab controls */}
        <Projects />

        {/* Professional Consultant Service Cards */}
        <Services />

        {/* Validated Inquiry Form + Contacts info */}
        <Contact />
      </main>

      {/* Standard Footers */}
      <Footer />

      {/* Expandable Virtual AI Twin conversational widget */}
      <AiChatbot isOpen={isAiChatOpen} onClose={() => setIsAiChatOpen(false)} />
    </div>
  );
}
