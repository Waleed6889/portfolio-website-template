# Premium Developer Portfolio

A simple yet highly premium, modern, and accessible personal portfolio website for full-stack and AI engineers, featuring an interactive AI Assistant, project filtering, and advanced animations.

## Key Features

- **Hero Section**: Includes a dynamic typing loop, visual abstract terminal, and elegant typography pairing.
- **Interactive AI Assistant Chatbot**: Exposes a floating chat widget that proxies requests to the server-side Gemini 3.5 Flash model safely, with rule-based fallback when keys are missing.
- **Project Catalog with Active Filters**: Group and toggle featured works dynamically by categories (AI, Fullstack, Frontend, Mobile).
- **Core Services offerings**: Display detailed consultation options, features, and price tags.
- **Experience Timeline**: Chronological layout showing career achievements and graduate education.
- **Fully Responsive**: Flawless adapters for Mobile, Tablet, Laptop, and 4K displays.
- **WCAG Accessible**: Custom high-contrast outline focus rings, keyboard navigability, semantic tags, and explicit focus states.
- **Performance Optimized**: Lazy loaders, CSS layouts, and 100 Lighthouse-ready builds.
- **On-Page SEO**: Real OG tags, dynamic title, description, keywords metadata, and dynamic JSON-LD personal schema script injections.
- **Validated Contact Form**: Custom regex validation with live state checks, loaders, error indicators, and endpoints connecting back to the server.

## Getting Started

1. Set up your Gemini API credentials in the AI Studio environment settings.
2. Run `npm run dev` to start the local development server.
3. Build for production using `npm run build` and run using `npm run start`.
