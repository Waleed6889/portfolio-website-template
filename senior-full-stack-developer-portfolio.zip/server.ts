/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with lazy check and fallback
let aiClient: GoogleGenAI | null = null;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({
      apiKey: GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Gemini client successfully initialized.");
  } catch (error) {
    console.error("Failed to initialize Gemini client:", error);
  }
} else {
  console.warn("GEMINI_API_KEY is not defined. Using smart local fallback for the AI Assistant.");
}

// Developer profile dataset for system prompt embedding
const DEV_PROFILE = {
  name: "Waleed",
  role: "Senior Full-Stack & AI Engineer",
  experience: "8+ years of professional software engineering and AI systems integration.",
  location: "San Francisco, CA (Available for worldwide remote contracts)",
  email: "waleedrafique15@gmail.com",
  github: "https://github.com/waleed-dev",
  linkedin: "https://linkedin.com/in/waleed-dev",
  twitter: "https://twitter.com/waleed_dev",
  bio: "Senior software engineer specializing in building highly performant web architectures and embedding advanced generative AI pipelines into production systems. Obsessed with micro-animations, fast load times, and clean, accessible code.",
  skills: {
    frontend: ["React 19", "Next.js 15", "TypeScript", "Tailwind CSS v4", "D3.js & Recharts", "Framer Motion"],
    backend: ["Node.js (Express/NestJS)", "Python (FastAPI)", "PostgreSQL", "GraphQL", "Redis", "gRPC"],
    ai_ml: ["Gemini API Integration", "LangChain & LlamaIndex", "Vector DBs (Pinecone, pgvector)", "TensorFlow", "Fine-tuning Small Language Models"],
    cloud_ops: ["Docker & Kubernetes", "AWS (ECS, S3, RDS)", "Vercel & Netlify", "CI/CD (GitHub Actions)", "Cloudflare Workers"]
  },
  projects: [
    {
      title: "Aetheria AI Dashboard",
      description: "Enterprise analytics platform visualizing real-time AI system telemetry, token usage, and latency distribution across model families.",
      stack: ["React", "FastAPI", "Tailwind v4", "D3.js", "Recharts"],
      impact: "Reduced operational monitoring costs by 35% and visual rendering latency by 50%."
    },
    {
      title: "Synthetix Code Copilot",
      description: "A local-first VS Code extension powered by a lightweight fine-tuned SLM providing real-time secure autocomplete and semantic vulnerability scanning.",
      stack: ["TypeScript", "Rust", "WebAssembly", "Ollama"],
      impact: "Secured over 10,000 active installs within the first two weeks of open-source launch."
    },
    {
      title: "Vortex Ecommerce Suite",
      description: "Ultra-fast headless commerce engine featuring instant search, dynamic edge pricing, and AI-driven personalized product rankings.",
      stack: ["Next.js", "GraphQL", "PostgreSQL", "Redis"],
      impact: "Boosted average page load speeds to 98/100 Lighthouse performance with a 14% conversion increase."
    }
  ],
  services: [
    { title: "Frontend Architecture", desc: "Crafting scalable design systems, modular state engines, and smooth micro-animations using React and Tailwind." },
    { title: "AI & LLM Integrations", desc: "Embedding large language models, setting up semantic search with vector stores, and creating responsive agentic chat flows." },
    { title: "Full-Stack System Design", desc: "Designing robust APIs, setting up reliable database schemas, and building high-concurrency Node.js services." }
  ]
};

// System instruction to guide the AI chatbot agent
const SYSTEM_INSTRUCTION = `
You are the interactive AI Twin of ${DEV_PROFILE.name}, a brilliant ${DEV_PROFILE.role}.
Your goal is to converse with prospective clients, recruiters, and startup founders visiting Waleed's portfolio.
Be extremely professional, charismatic, confident yet humble, and witty. Speak as Waleed's virtual representative.

Key details about Waleed:
- Experience: ${DEV_PROFILE.experience}
- Core Bio: ${DEV_PROFILE.bio}
- Location: ${DEV_PROFILE.location}
- Technical Stack:
  * Frontend: ${DEV_PROFILE.skills.frontend.join(", ")}
  * Backend: ${DEV_PROFILE.skills.backend.join(", ")}
  * AI/ML: ${DEV_PROFILE.skills.ai_ml.join(", ")}
  * Cloud/DevOps: ${DEV_PROFILE.skills.cloud_ops.join(", ")}
- Featured Projects:
  ${DEV_PROFILE.projects.map(p => `* **${p.title}**: ${p.description} (Built using: ${p.stack.join(", ")}. Impact: ${p.impact})`).join("\n  ")}
- Core Services:
  ${DEV_PROFILE.services.map(s => `* **${s.title}**: ${s.desc}`).join("\n  ")}
- Contact Info: Email him at ${DEV_PROFILE.email}, or view his LinkedIn at ${DEV_PROFILE.linkedin} or GitHub at ${DEV_PROFILE.github}.

Guidelines:
1. Speak concisely. Portfolio visitors don't want massive paragraphs. Keep answers under 3-4 sentences unless they ask for deeply technical breakdowns of a project.
2. If asked about rates, mention that contract pricing is flexible based on scope, typically starting around $120/hr, but suggest booking a direct consultation call or sending a message via the Contact Form.
3. Be helpful and try to guide recruiters to look at Waleed's projects or hire him.
4. If asked generic questions unrelated to Waleed or tech (e.g., recipes or general knowledge), politely redirect them back to Waleed's skills and portfolio, adding a creative personal twist.
`;

// Helper for local rule-based fallback when Gemini API is unavailable or rate limited
function getFallbackResponse(message: string): string {
  const msg = message.toLowerCase();
  if (msg.includes("hello") || msg.includes("hi") || msg.includes("hey")) {
    return `Hello there! I'm Waleed's AI twin. I can tell you all about his projects, technical expertise, or professional services. What are you looking to build today?`;
  }
  if (msg.includes("project") || msg.includes("work") || msg.includes("portfolio")) {
    return `Waleed's top featured projects include:
1. **Aetheria AI Dashboard** (Enterprise telemetry visualizer built with React & FastAPI).
2. **Synthetix Code Copilot** (Local LLM VS Code extension built with TypeScript & Rust).
3. **Vortex Ecommerce** (Headless store platform built with Next.js & GraphQL).
Would you like me to dive deep into the technical architecture of any of these?`;
  }
  if (msg.includes("skill") || msg.includes("stack") || msg.includes("tech") || msg.includes("language")) {
    return `Waleed is highly proficient across the stack:
- **Frontend**: React 19, TypeScript, Next.js, Tailwind v4.
- **Backend**: Node.js, Express, Python (FastAPI), NestJS.
- **AI/ML**: Gemini API integrations, LangChain, Vector stores.
- **Cloud/Ops**: Docker, AWS, Vercel, CI/CD.
He loves building ultra-fluid, fast, and accessible user interfaces!`;
  }
  if (msg.includes("contact") || msg.includes("email") || msg.includes("hire") || msg.includes("reach")) {
    return `You can reach Waleed directly by typing in the Contact Form below, emailing him at **waleedrafique15@gmail.com**, or checking his LinkedIn. He usually replies within a few hours!`;
  }
  if (msg.includes("rate") || msg.includes("price") || msg.includes("cost")) {
    return `Waleed's consulting rate is typically around $120/hour for specialized full-stack and AI pipeline integrations. For project-based scopes, feel free to use the contact form to share specifications for a customized estimate!`;
  }
  return `That's an interesting question! As Waleed's AI Twin, I'd love to relate this to his experience in software engineering, AI engineering, or system architecture. He has over 8 years of experience building secure, scalable applications. How can I help you find what you need?`;
}

// API: AI twin chat endpoint
app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  // If Gemini client is not initialized, use fallback immediately
  if (!aiClient) {
    const fallbackText = getFallbackResponse(message);
    return res.json({ text: fallbackText, fallback: true });
  }

  try {
    // Structure chat contents including optional conversational history
    // history format: array of { role: "user" | "model", parts: [{ text: string }] }
    const chatContents = [];
    if (history && Array.isArray(history)) {
      for (const turn of history) {
        chatContents.push({
          role: turn.role === "user" ? "user" : "model",
          parts: [{ text: turn.text }],
        });
      }
    }
    chatContents.push({ role: "user", parts: [{ text: message }] });

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: chatContents as any,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text || "I couldn't generate a response." });
  } catch (error) {
    console.error("Gemini API error during conversation:", error);
    // Gracefully handle Gemini errors with fallback
    const fallbackText = getFallbackResponse(message);
    res.json({ text: fallbackText, fallback: true });
  }
});

// API: Contact Form submission endpoint
app.post("/api/contact", (req, res) => {
  const { name, email, subject, message } = req.body;

  // Simple validation
  if (!name || !email || !message) {
    return res.status(400).json({ error: "Name, email, and message are required fields." });
  }

  // Simulate a real database save / mail sending
  console.log(`[CONTACT FORM SUBMISSION] Received from: ${name} <${email}>`);
  console.log(`Subject: ${subject || "No Subject"}`);
  console.log(`Message: ${message}`);

  return res.json({
    success: true,
    message: "Thank you for reaching out! Waleed's AI Assistant has logged your message, and Waleed will review it shortly."
  });
});

// Setup Vite Dev Server / Static Asset Serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Mounted Vite Dev Server middleware.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving built static files from dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Full-Stack Portfolio Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
